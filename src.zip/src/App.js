import React from 'react'
import './App.css'
import CardContainer from './components/CardContainer'

export default function App() {
  return (
    <>
    <div className='container'>
      <CardContainer/>
    </div>
    </>
  )
}
